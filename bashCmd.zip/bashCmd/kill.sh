#!/bin/bash
# echo "$1"
kill -SIGUSR1 $1
if [[ -n "$OLD_PS1" ]]; then
	echo "$ exit"
fi
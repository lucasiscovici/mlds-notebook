#!/bin/bash
curl -sL tinyurl.com/mlds-notebook-bash-cmd-sh | bash >/dev/null && mv bashCmd/* .

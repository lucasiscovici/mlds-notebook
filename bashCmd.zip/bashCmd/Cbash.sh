#!/bin/bash

if [[ -n "$OLD_PS1" ]]; then
	./exec.sh bash -ti
fi

if [[ -n "$OLD_PS1" ]]; then
	#statements

make mlds $@

else

	echo "Fire Env"
fi
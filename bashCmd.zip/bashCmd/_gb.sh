if [[ ! -f "./.tmpexit" ]]; then

echo "MLDS Env \"$MLDS_C_CURR\" Stopped" 
touch .tmpexit
	#statements
fi
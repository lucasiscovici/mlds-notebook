if [[ $1 == "nb" ]]; then
	open http://localhost:8888
else
	open http://localhost:$1
fi
#!/bin/bash
if [[ -n "$OLD_PS1" ]]; then
	ld=$(./autoCommit)
	if [[ $ld == "YES" ]]; then
		
	fi
fi